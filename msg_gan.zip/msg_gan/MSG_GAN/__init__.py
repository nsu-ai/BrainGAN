""" Package has implementation of Teacher project
    The gan architecture supplies gradients to the generator
    at different scales for image Generation
"""
from MSG_GAN import GAN
from MSG_GAN import CustomLayers
from MSG_GAN import Losses
